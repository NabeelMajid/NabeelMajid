
public class Point
{
    // instance variables - replace the example below with your own
    private double x;
    private double y;

    
    public void setPoints(double a,double b)//take two points as parameter
    {
        // Initialize instance variables
        x=a;
        y=b;
    }
    public double distance(Point a)//to find distance from origin
    {
     double d;
     d=Math.sqrt(Math.pow((a.get_x()-0),2)+Math.pow((a.get_y()-0),2));
     return d;
    }
    //settters and getters
    public double get_x()
    {
        return x;
    }
    public double get_y()
    {
        return y;
    }
     public void set_x(double a)
    {
        x=a;
    }
    public void set_y(double b)
    {
        y=b;
    }
    //to string method
    public String toString()
    {
        return "("+x+","+y+")";
    }
   
}

