

public class MyPolygon//linkedlist to store Polygon
{
    
    private Node head;
    private Node tail;
    private Node current;
    private int size;
    int count=0;

    public MyPolygon()//constructor
    {
        head=null;
        tail=null;
        current=null;
        size=0;
        
    }
    public void prepend(Polygon data)//at head
    {
        if (head == null)
        {
            head= new Node(data);
            tail = head;
            current=head;
            size++;
        }
        else
        {
            
          Node temp=new Node(data);
          temp.set_next(head);
           head.set_prev(temp);
           head=temp;
            size++;
        }
        
    }
    public void append (Polygon data)//at tail
    {
        if (head == null)
        {
            head= new Node(data);
            tail=head;
            size++;
            current=head;
        }
        else
        {
            
            Node temp=new Node(data);
            tail.set_next(temp);
            temp.set_prev(tail);
            tail=temp;
            size++;
            current=head;
            
        }
        
    }
    
    public void insert (Polygon p)//add before current
    {
        
        Node newNode = new Node(p);
        newNode.set_next(current.getNext());
        newNode.set_prev (current );
        current.set_next(newNode);
        current.getNext().set_prev( newNode );
    }
//setter and getters
    public void Next()
    {
        current=current.getNext();
    }
    public void reset()
    {
        current=head;
    }
    public Polygon take()
    {
        current=head;
        head=head.getNext();
        head.set_prev(null);
        current.set_next(null);
        return current.get_data();
    }
    public Node getHead()
    {
        return head;
    }
    public Node getTail()
    {
        return tail;
    }
    
    public int get_size()
    {
    return size;
    }
    public Node getCurrent() {
        
        return current;
    }
    public String toString()
    {
        String result="";
        Node temp=this.head;
        while(temp!=null)
        {
            result=result+temp.get_data().toString()+"\n";
            temp=temp.getNext();
        }
        return result;
    }
    

    
    
       }













