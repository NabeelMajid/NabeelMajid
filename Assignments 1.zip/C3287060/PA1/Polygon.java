
public class Polygon implements Comparable<Polygon>
{
	 Point []vertice;//to store points
	 double area=0;
   
   

   public void Polygon(int n)//its a method not a constructor
   
   {
	   
       vertice=new Point[n];//initailizing it with number of sides of polygon
       for(int i=0;i<n;i++)
       {
           vertice[i]=new Point();
           
        }
        
    }
   //settters
   public void setVertice(Point p,int i)
   {
       
             
              vertice[i].set_x(p.get_x());
              vertice[i].set_y(p.get_y());
              
             
       
    }
   //to string method
   public String toString()
    {
                
        String str = "[";
        if(vertice != null)
        {
            for(int x = 0; x < vertice.length; x++)
            {
                str += "("+vertice[x].get_x()+","+vertice[x].get_y()+") ";               
            }
        }
        else{
            str = null;
        }
        return str+"]:   " +area;
    }
   //cross product
   public double c_prod(Point p1, Point p2)
   {
       return (p1.get_x() * p2.get_y())-(p1.get_y()*p2.get_x());
    }
    public void Cal_area(int n)//to calculate area of polygon
    {
        double sum=0;
        for(int i=0;i<n-1;i++)
        {
        sum+=c_prod(this.vertice[i],this.vertice[i+1%n]);//calcs cross product and take modulus
        }
        area= Math.abs(sum)/2;
    }

	public int compareTo(Polygon list2_a) //comapre to
	{
		
		
		if(list2_a.getarea()<this.area)//to add at head
		{
			
			
			return 1;
		}
		else if(list2_a.getarea() > this.area )//if greater then 
		{
			return -1;
		}
		else if(list2_a.getarea()==this.area)//equal to
		{
			return 0;
		}
		return 0;
	}
	
	public double getarea()
	{
		return area;
	}

	
		
	}	
    

	
	

    
   
   

    

 
