
    
public class Node//node class take polygon as data
{
    private Polygon data;
    private Node next;
    private Node prev;      
            
    public Node(Polygon data)//constructor
   {
    this.data=data;  
    next=null;
    prev=null;
    }
    //setters and getters
   void set_data (Polygon data)
   {
       this.data=data;
    }
   void set_next(  Node  next)
   {
       this.next=next;
    }
   void set_prev( Node prev)
   {
       this.prev=prev;
    }
   Polygon get_data()
   {
       return data;
    }
   public Node getNext()
   {
       return next;
    }
   public Node getPrev()
   {
       return prev;
    }
}