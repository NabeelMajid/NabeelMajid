import java.util.Scanner;
import java.io.*;
// main class
public class PA1 
{
     private Point p=null;
     private MyPolygon list;
     private MyPolygon list2;
     private Polygon poly;
     
    public static void main(String[] args) throws FileNotFoundException, IOException
     
     {
                
                double num1=0;
                double num2=0;
                Point p=new Point();
                MyPolygon list=new MyPolygon();//linked list  to store polygon
                MyPolygon list2=new MyPolygon();//for sorted polygon
               
                int n=0;//to know the size of scanner
                
                Scanner fin = null;
              try//opening file
              {
                  File file =new File("sample_in.txt");
                  fin=new Scanner(file);
                  //opening file
                }
                catch(Exception e)
                {
                    System.out.println("Error opening file/n");
                }
                while(fin.hasNext())//reading from file and storing it in point object
                {
                    
                    String word = fin.next();//reading by line
                                     
                    Polygon poly = null;
                    poly=new Polygon();
                     
                        if(word.charAt(0)=='P')//checking for polygon
                        {
                                            
                           n=fin.nextInt();//getting number of sides for polygon
                          poly.Polygon(n);
                           
                           
                                          
                            for(int i=0;i<n;i++)
                            {                   
                                num1=fin.nextDouble();
                                num2=fin.nextDouble();
                                p.set_x(num1);//point x
                                p.set_y(num2);//point y
                               
                                poly.setVertice(p,i);//setting vertices for polygon point type
                      
                                poly.Cal_area(n); //calculating area
                                                                    
                            }
                            
                          
                            }
                        list.append(poly);//adding into list
                        list2.reset();
                        
                       sorted(list2,poly);//for sorted list
                        
                    //sorted method doesnot work properly.
                        
                        
                    
                       
                
                
                
                
               
                 //to output in file
             File f=new File("sample.out.txt");
         FileWriter fw= new FileWriter(f);
         fw.write(list.toString()+"\n\n");
         fw.write(list2.toString());
         
         fw.close();
         
                }
         }//main function
         //for sorted list
    public static  void sorted(MyPolygon list2, Polygon poly2)  
    {
        
        
         
          
        // if list is empty  
        if (list2.getHead() == null) 
        {
            list2.prepend(poly2);
        }  

        // if the node is to be inserted at the beginning  
        // of the doubly linked list  
        else if (poly2.compareTo(list2.getHead().get_data()) == 1) 
        { 
            
           list2.prepend(poly2);
        } 
        else 
        { 
           //list2.reset();

            // locate the node after which the new node  
            // is to be inserted  
            while (list2.getCurrent().getNext() != null)
            {
                if( poly2.compareTo(list2.getCurrent().get_data()) ==-1 )  
                {
                    
                    list2.append(poly2);
                    break;
                }
                else if(poly2.compareTo(list2.getCurrent().get_data()) ==0) 
                {
                    list2.insert(poly2);
                    
                }
                    
                  else  
                    {
                        list2.append(poly2);
                    }
                list2.Next();
            }
            
          

            
            
          
         
          
        } 
    }
                
}



